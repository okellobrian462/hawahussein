header.php<!DOCTYPE html>

<html lang="en">


<!--[if (gte IE 9)| IEMobile |!(IE)]><html class="no-js" lang="en"><![endif]-->

<!-- Mirrored from www.hawahussein.com/en/global/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 27 Jun 2025 11:53:07 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Hawa and Hussein LLP | Global Law Firm</title>

    



<!-- Google CSE Section Filter -->
<meta name="limitfilter" />

<meta name="description" content="Sidley is a global law firm, collaborating across disciplines and borders to help clients in more than 70 countries achieve business objectives." />
<meta name="keywords" content="" />

<meta property="og:url" content="index.html" />
<meta property="og:type" content="website" />
<meta property="og:title" content="" />
<meta property="og:description" content="" />
    <meta property="og:image" content="../../-/media/social-media-directory/mn16280rushupdatetoopengraph1080.jpg?la=en&amp;rev=29b36c9a6f734445a51dcd355595b24b" />

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@SidleyLaw">
<meta name="twitter:title" content="">
<meta name="twitter:description" content="">
    <meta name="twitter:image" content="../../-/media/social-media-directory/mn16280rushupdatetoopengraph1080.jpg?la=en&amp;rev=29b36c9a6f734445a51dcd355595b24b">


<meta name="facebook-domain-verification" content="lc00ncyp9ydcelxe8s4w4110x62xg6" />


    <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "WebSite",
          "url": "https://www.hawahussein.com/en/global/",
          "potentialAction": [{
            "@type": "SearchAction",
            "target": {
              "@type": "EntryPoint",
              "urlTemplate": "https://www.hawahussein.com/en/global/search/#q={search_term_string}&t=coveo900ef9d2"
            },
            "query-input": "required name=search_term_string"

          }]
        }
    </script>

    <meta name='robots' content='index,follow'>
    
<link rel='alternate' hreflang='x-default' href='https://www.hawahussein.com/en/us/' /><link href='https://www.hawahussein.com/en/us/' rel='canonical' /><link rel='alternate' hreflang='en' href='https://www.hawahussein.com/en/us/' /><link rel='alternate' hreflang='zh-Hans' href='https://www.hawahussein.com/zh-hans/ap/' /><link rel='alternate' hreflang='ja' href='https://www.hawahussein.com/ja/ap/' />

    <link rel="preconnect" href="https://p.typekit.net/" />
    <link rel="preconnect" href="https://siteimproveanalytics.com/" />
    <link rel="preconnect" href="https://www.google-analytics.com/" />
    <link rel="preload" href="https://www.hawahussein.com/assets/release/fonts/light/BlackTie-Light-webfont.woff2?v=1.0.0" as="font" crossorigin="anonymous" type="font/woff2" />
    <link rel="preload" href="https://www.hawahussein.com/assets/release/fonts/regular/BlackTie-Regular-webfont.woff2?v=1.0.0" as="font" crossorigin="anonymous" type="font/woff2" />
    <link rel="preload" href="https://www.hawahussein.com/assets/release/fonts/solid/BlackTie-Solid-webfont.woff2?v=1.0.0" as="font" crossorigin="anonymous" type="font/woff2" />
    <link rel="preload" href="https://www.hawahussein.com/assets/release/fonts/brands/fa-brands-400.woff2" as="font" crossorigin="anonymous" type="font/woff2" />
    <link rel="preload" href="https://www.hawahussein.com/assets/release/fonts/solid/fa-solid-900.woff2" as="font" crossorigin="anonymous" type="font/woff2" />

    <link rel="stylesheet" href="../../assets/release/styles/main.bundle.v-emczro3ts8lqyjdb2b47g.css" media="screen" as="style">
    <link rel="stylesheet" href="../../Coveo/css/main/MainCoveoFullSearchNewDesign.min.v-gdhck7mbdu41rydkxs7sw.css" media="screen" as="style">
    <link rel="stylesheet" href="../../Coveo/css/main/MainCoveoComponent.v-2ypftq5xhzsdpcxtegjbq.css" media="screen" as="style">
    <script src="../../../use.typekit.net/mhr2smi.js"></script>
    <script type="text/javascript" src="../../../fast.fonts.net/jsapi/25e0860a-7f67-4249-ae7f-71d9018f6f24.js"></script>

    <script>try { Typekit.load({ async: true }); } catch (e) { }</script>
    <link rel="stylesheet" type="text/css" href="../../../fast.fonts.net/cssapi/8feb5ce2-2c93-46b6-9f44-608c4c2928d3.css" media="screen" />

    <script src="../../../cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js" defer></script>
    <script src="../../../cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.7/ScrollMagic.min.js" defer></script>
    <script src="../../../cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.7/plugins/animation.gsap.min.js" defer></script>
    <script src="../../assets/release/scripts/main/libs.bundle.v-st3yd6bpodchjwv3vhkrg.js"></script>
        <script src="../../assets/release/scripts/page/site-improve-custom.v-ckrbfapghnzgvjnldznpkw.js" async></script>
        <script src="../../assets/release/scripts/page/es6-promise.auto.min.v-nwuhkl6ncx0fnquszna.js" defer></script>
        <link rel="stylesheet" href="../../assets/release/styles/print.bundle.v-no45eyuyndozo7q2vwd54a.css" media="print" as="style">
        <link rel="shortcut icon" type="image/x-icon" href="https://www.hawahussein.com/assets/release/img/favicon.v-28fhqfo7ertqhjixpwx0vw.ico" />
        <!--[if lte IE 9]>
            <script type="text/javascript">
                window.location = "/legacybrowser";
            </script>
        <![endif]-->
        <!-- Google Tag Manager -->
        <script>
            (function (w, d, s, l, i) {
                w[l] = w[l] || []; w[l].push({
                    'gtm.start':

                        new
                            Date().getTime(), event: 'gtm.js'
                }); var f = d.getElementsByTagName(s)[0],

                    j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =

                        '../../../www.googletagmanager.com/gtm5445.html?id=' + i + dl; f.parentNode.insertBefore(j, f);

            })(window, document, 'script', 'dataLayer', 'GTM-KKQHWNC');</script>
        <!-- End Google Tag Manager -->
</head>
